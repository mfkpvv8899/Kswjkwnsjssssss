package com.minimal.launcher

import android.app.ActivityOptions
import android.content.*
import android.os.BatteryManager
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.*
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); enableEdgeToEdge(); setContent { Launcher() } }
}

const val PIN = "1232" // senha dos apps ocultos

// ---------- Modelos ----------
class AppInfo(val label: String, val pkg: String, val intent: Intent, val icon: ImageBitmap)
class Th(val bg: List<Color>, val fg: Color, val accent: Color, val card: Color, val onCard: Color)

val THEMES = listOf(
    "Dark Samurai" to Th(listOf(Color(0xFF000000), Color(0xFF121212)), Color.White, Color(0xFFFFB6C8), Color(0xFF161616), Color.White),
    "Yellow Modern" to Th(listOf(Color(0xFFFFD43B), Color(0xFFD99A00)), Color(0xFF1A1A1A), Color(0xFF2B2B2B), Color(0xFF2B2B2B), Color.White),
    "Monochrome" to Th(listOf(Color(0xFF2E2E2E), Color(0xFF050505)), Color.White, Color.White, Color(0xFF101010), Color.White),
)
val FONTS = listOf("Sans" to FontFamily.SansSerif, "Serif" to FontFamily.Serif, "Mono" to FontFamily.Monospace, "Script" to FontFamily.Cursive)

fun Th.light(on: Boolean, i: Int) = if (!on || i == 1) this else
    Th(listOf(Color(0xFFF5F5F5), Color(0xFFD9D9D9)), Color(0xFF111111), if (i == 0) Color(0xFFE48AA5) else Color(0xFF111111), Color.White, Color(0xFF111111))

// ---------- Dados ----------
fun loadApps(c: Context): List<AppInfo> {
    val pm = c.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(q, 0).map { r ->
        val a = r.activityInfo
        AppInfo(r.loadLabel(pm).toString(), a.packageName,
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(a.packageName, a.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            r.loadIcon(pm).toBitmap(96, 96).asImageBitmap())
    }.sortedBy { it.label.lowercase() }
}

fun defaultDock(c: Context, apps: List<AppInfo>): List<String> {
    val pm = c.packageManager
    return listOf(
        Intent(Intent.ACTION_DIAL),
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER),
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_GALLERY),
        Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
    ).mapNotNull { pm.resolveActivity(it, 0)?.activityInfo?.packageName }.filter { p -> apps.any { it.pkg == p } }.distinct()
}

fun launch(c: Context, a: AppInfo) = runCatching {
    c.startActivity(a.intent, ActivityOptions.makeCustomAnimation(c, android.R.anim.fade_in, android.R.anim.fade_out).toBundle())
}

@Composable fun rememberClock(): State<LocalDateTime> = produceState(LocalDateTime.now()) {
    while (true) { value = LocalDateTime.now(); delay(60_000L - System.currentTimeMillis() % 60_000L + 50) } // 1 tick/min: poupa bateria
}

@Composable fun rememberBattery(): State<Pair<Int, Boolean>> {
    val c = LocalContext.current
    return produceState(0 to false) {
        while (true) {
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
            val s = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            value = (l * 100 / s) to ((i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0)
            delay(30_000)
        }
    }
}

// ---------- Papéis de parede desenhados (leves, sem imagens) ----------
@Composable fun Wallpaper(i: Int, t: Th, light: Boolean) {
    Canvas(Modifier.fillMaxSize().background(Brush.verticalGradient(t.bg))) {
        val w = size.width; val h = size.height
        val ink = if (light) Color(0xFF111111) else Color.Black
        fun ridge(vararg p: Float, c: Color) = drawPath(Path().apply {
            moveTo(0f, h); lineTo(0f, h * p[0])
            for (k in 1 until p.size) lineTo(w * k / (p.size - 1), h * p[k]); lineTo(w, h); close() }, c)
        when (i) {
            0 -> { drawCircle(t.accent.copy(.85f), w * .26f, Offset(w * .72f, h * .30f))
                   drawLine(Color.White.copy(.9f), Offset(w * .12f, h * .92f), Offset(w * .62f, h * .50f), 5f, StrokeCap.Round)
                   ridge(.80f, .70f, .76f, .64f, .78f, c = ink) }
            1 -> { drawRect(Color(0xFF1A1A1A), Offset(w * .55f, 0f), Size(w * .45f, h * .28f))
                   drawCircle(Color(0xFF1A1A1A).copy(.15f), w * .5f, Offset(0f, h * .85f))
                   drawCircle(Color.White.copy(.35f), w * .12f, Offset(w * .78f, h * .14f)) }
            else -> { ridge(.62f, .52f, .66f, .45f, .60f, c = Color(0xFF3A3A3A)); ridge(.78f, .68f, .80f, .64f, .76f, c = Color(0xFF181818))
                      ridge(.90f, .86f, .92f, .88f, .90f, c = Color.Black) }
        }
    }
}

// ---------- UI ----------
@Composable fun Launcher() {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("p", 0) }
    var ti by remember { mutableIntStateOf(sp.getInt("theme", 0)) }
    var dockN by remember { mutableIntStateOf(sp.getInt("dock", 5)) }
    var alpha by remember { mutableFloatStateOf(sp.getFloat("alpha", .88f)) }
    var clockSz by remember { mutableFloatStateOf(sp.getFloat("clock", 96f)) }
    var h24 by remember { mutableStateOf(sp.getBoolean("h24", true)) }
    var lightM by remember { mutableStateOf(sp.getBoolean("light", false)) }
    var sysWp by remember { mutableStateOf(sp.getBoolean("syswp", false)) }
    var monoIcons by remember { mutableStateOf(sp.getBoolean("mono", true)) }
    var fi by remember { mutableIntStateOf(sp.getInt("font", 0)) }
    var name by remember { mutableStateOf(sp.getString("name", "") ?: "") }
    var pinned by remember { mutableStateOf(sp.getString("pins", "")!!.split(",").filter { it.isNotBlank() }) }
    var drawer by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var hidden by remember { mutableStateOf(sp.getString("hidden", "")!!.split(",").filter { it.isNotBlank() }.toSet()) }
    var unlocked by remember { mutableStateOf(false) }
    var pinDialog by remember { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }

    LaunchedEffect(ti, dockN, alpha, clockSz, h24, lightM, sysWp, monoIcons, fi, name, pinned, hidden) {
        sp.edit().putInt("theme", ti).putInt("dock", dockN).putFloat("alpha", alpha).putFloat("clock", clockSz)
            .putBoolean("h24", h24).putBoolean("light", lightM).putBoolean("syswp", sysWp).putBoolean("mono", monoIcons)
            .putInt("font", fi).putString("name", name).putString("pins", pinned.joinToString(",")).putString("hidden", hidden.joinToString(",")).apply()
    }

    val apps by produceState(emptyList<AppInfo>()) { value = withContext(Dispatchers.IO) { loadApps(ctx) } }
    val th = THEMES[ti].second.light(lightM, ti)
    val font = FONTS[fi].second
    val now by rememberClock()
    val (bat, charging) = rememberBattery().value
    val shape = if (ti == 1) RoundedCornerShape(4.dp, 40.dp, 4.dp, 40.dp) else RoundedCornerShape(32.dp)
    val dockApps = (pinned.ifEmpty { defaultDock(ctx, apps) }).filter { it !in hidden }.mapNotNull { p -> apps.find { it.pkg == p } }.take(dockN)
    val iconFilter = if (monoIcons) ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) }) else null

    BackHandler(drawer || settings) { drawer = false; settings = false; unlocked = false }
    LaunchedEffect(drawer) { if (!drawer) { unlocked = false; query = "" } }

    Box(Modifier.fillMaxSize()) {
        if (sysWp) Box(Modifier.fillMaxSize().background(Color.Black.copy(.25f))) else Wallpaper(ti, th, lightM)

        // ---------- HOME ----------
        Box(Modifier.fillMaxSize()
            .pointerInput(Unit) { detectTapGestures(onLongPress = { settings = true }) }
            .pointerInput(Unit) {
                var d = 0f
                detectVerticalDragGestures(onDragStart = { d = 0f }, onVerticalDrag = { _, a -> d += a },
                    onDragEnd = {
                        if (d < -90) drawer = true
                        else if (d > 90) runCatching { Class.forName("android.app.StatusBarManager")
                            .getMethod("expandNotificationsPanel").invoke(ctx.getSystemService("statusbar")) }
                    })
            }) {
            Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 24.dp, vertical = 20.dp)) {
                val g = when (now.hour) { in 5..11 -> "Bom dia"; in 12..17 -> "Boa tarde"; else -> "Boa noite" }
                Text(if (name.isBlank()) g else "$g, $name", color = th.accent, fontFamily = font, fontSize = 18.sp)
                Text(now.format(DateTimeFormatter.ofPattern(if (h24) "HH:mm" else "h:mm")),
                    color = th.fg, fontFamily = font, fontSize = clockSz.sp, lineHeight = clockSz.sp,
                    fontWeight = if (ti == 2) FontWeight.Black else FontWeight.Light)
                Text(now.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM yyyy", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() },
                    color = th.fg.copy(.8f), fontFamily = font, fontSize = 16.sp)
                Text("${if (charging) "⚡ " else ""}$bat% bateria", color = th.fg.copy(.6f), fontSize = 14.sp)
                Spacer(Modifier.height(28.dp))

                Row(Modifier.fillMaxWidth().height(160.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column(Modifier.weight(1.5f).fillMaxHeight().clip(shape).background(th.card.copy(alpha)).padding(20.dp),
                        verticalArrangement = Arrangement.SpaceBetween) {
                        Text(now.format(DateTimeFormatter.ofPattern("EEE", Locale("pt", "BR"))).uppercase(), color = th.accent.takeIf { ti != 1 } ?: Color(0xFFFFD43B), fontSize = 14.sp)
                        Text("${now.dayOfMonth}", color = th.onCard, fontFamily = font, fontSize = 64.sp, fontWeight = FontWeight.Bold)
                        Text(now.format(DateTimeFormatter.ofPattern("MMMM", Locale("pt", "BR"))), color = th.onCard.copy(.7f))
                    }
                    Box(Modifier.weight(1f).fillMaxHeight().clip(shape).background(th.card.copy(alpha)).padding(20.dp), contentAlignment = Alignment.Center) {
                        val ac = if (ti == 1) Color(0xFFFFD43B) else th.accent
                        Canvas(Modifier.fillMaxSize()) {
                            drawArc(Color.White.copy(.12f), 0f, 360f, false, style = Stroke(12f, cap = StrokeCap.Round))
                            drawArc(ac, -90f, bat * 3.6f, false, style = Stroke(12f, cap = StrokeCap.Round))
                        }
                        Text("$bat%", color = th.onCard, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // ---------- DOCK flutuante ----------
            Row(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp)
                .clip(RoundedCornerShape(32.dp)).background(th.card.copy(alpha)).padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                dockApps.forEach { a ->
                    Image(a.icon, a.label, Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).clickable { launch(ctx, a) }, colorFilter = iconFilter)
                }
                if (dockApps.isEmpty()) Text("Segure um app na lista para fixar", color = th.onCard.copy(.6f), fontSize = 12.sp)
            }
        }

        // ---------- GAVETA DE APPS ----------
        AnimatedVisibility(drawer, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
            val list = apps.filter { it.label.contains(query, true) && (it.pkg in hidden) == unlocked }
            Column(Modifier.fillMaxSize().background(Color.Black.copy(.93f)).statusBarsPadding().padding(horizontal = 16.dp)) {
                Box(Modifier.fillMaxWidth().height(32.dp).pointerInput(Unit) {
                    var d = 0f
                    detectVerticalDragGestures(onDragStart = { d = 0f }, onVerticalDrag = { _, a -> d += a }, onDragEnd = { if (d > 40) drawer = false })
                }, contentAlignment = Alignment.Center) { Box(Modifier.width(44.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color.White.copy(.4f))) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text(if (unlocked) "Buscar apps ocultos" else "Buscar apps") },
                        shape = RoundedCornerShape(28.dp), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White))
                    TextButton({ if (unlocked) unlocked = false else pinDialog = true }) { Text(if (unlocked) "Sair" else "Ocultos", color = th.accent) }
                }
                if (unlocked) Text("Apps ocultos", color = th.accent, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                    shape = RoundedCornerShape(28.dp), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White))
                LazyVerticalGrid(GridCells.Adaptive(76.dp), Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 16.dp, horizontal = 0.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(list, key = { it.pkg + it.label }) { a ->
                        Column(Modifier.combinedClickable(onClick = { launch(ctx, a); drawer = false; query = "" },
                            onLongClick = { menuApp = a }),
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(a.icon, a.label, Modifier.size(52.dp), colorFilter = iconFilter)
                            Text(a.label, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }

        // ---------- CONFIGURAÇÕES (segurar na HOME) ----------
        AnimatedVisibility(settings, Modifier.align(Alignment.BottomCenter), enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
            CompositionLocalProvider(LocalContentColor provides th.onCard) {
                Column(Modifier.fillMaxWidth().fillMaxHeight(.72f).clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                    .background(th.card).verticalScroll(rememberScrollState()).navigationBarsPadding().padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Personalizar", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        THEMES.forEachIndexed { i, p -> FilterChip(ti == i, { ti = i }, { Text(p.first, fontSize = 12.sp) }) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FONTS.forEachIndexed { i, p -> FilterChip(fi == i, { fi = i }, { Text(p.first) }) }
                    }
                    OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Nome na saudação") })
                    Text("Tamanho do relógio"); Slider(clockSz, { clockSz = it }, valueRange = 56f..140f)
                    Text("Transparência dos widgets"); Slider(alpha, { alpha = it }, valueRange = .2f..1f)
                    Text("Ícones no dock: $dockN"); Slider(dockN.toFloat(), { dockN = it.toInt() }, valueRange = 3f..6f, steps = 2)
                    Sw("Relógio 24h", h24) { h24 = it }
                    Sw("Modo claro", lightM) { lightM = it }
                    Sw("Ícones monocromáticos", monoIcons) { monoIcons = it }
                    Sw("Usar papel de parede do sistema", sysWp) { sysWp = it }
                    Button({ ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Papel de parede").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, Modifier.fillMaxWidth()) { Text("Trocar papel de parede") }
                    OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, Modifier.fillMaxWidth()) { Text("Definir como launcher padrão") }
                    TextButton({ pinned = emptyList() }) { Text("Restaurar dock padrão") }
                }
            }
        }

        menuApp?.let { a ->
            AlertDialog(onDismissRequest = { menuApp = null }, title = { Text(a.label) },
                text = { Column {
                    TextButton({ pinned = (listOf(a.pkg) + pinned.ifEmpty { defaultDock(ctx, apps) }).distinct().take(8); menuApp = null }) { Text("Fixar no dock") }
                    TextButton({ hidden = if (a.pkg in hidden) hidden - a.pkg else hidden + a.pkg; menuApp = null }) { Text(if (a.pkg in hidden) "Reexibir app" else "Ocultar app") }
                } },
                confirmButton = {}, dismissButton = { TextButton({ menuApp = null }) { Text("Cancelar") } })
        }
        if (pinDialog) {
            var pin by remember { mutableStateOf("") }
            var err by remember { mutableStateOf(false) }
            AlertDialog(onDismissRequest = { pinDialog = false }, title = { Text("Apps ocultos") },
                text = { OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(8); err = false }, singleLine = true, isError = err,
                    label = { Text("Senha") }, supportingText = { if (err) Text("Senha incorreta") },
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)) },
                confirmButton = { TextButton({ if (pin == PIN) { unlocked = true; pinDialog = false } else err = true }) { Text("Abrir") } },
                dismissButton = { TextButton({ pinDialog = false }) { Text("Cancelar") } })
        }
    }
}

@Composable fun Sw(t: String, v: Boolean, c: (Boolean) -> Unit) =
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(t, Modifier.weight(1f)); Switch(v, c) }
